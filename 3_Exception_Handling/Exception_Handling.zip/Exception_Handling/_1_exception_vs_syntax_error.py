"""
1 - Exception vs. Syntax Error:

A Python program stops execution when it encounters an error.
The process of managing these situations is called Exception Handling.

There are two types of errors in Python:
 * Syntax Error (Design-Time error)
 * Exception (Run-Time error)
"""

"""
Syntax Error (Design-Time error):

If the code you write doesn't comply with Python syntax, the Python Parser will raise 'Syntax Error'.

Error Type: SyntaxError
"""

# Ex:
# SyntaxError
# print('Python Parser error'))

# Ex:
# SyntaxError: EOL while scanning string literal
# a = "12'
# print(a)

# Ex:
# IndentationError: expected an indented block
# def myFunc():
#     # function scope
# print('A')


"""
Exception: 
Let's assume, your code is syntactically correct. So it will start execution. 
If it encounters an unexpected situation (error) during the execution (run-time), Python Interpreter will raise an error.
This is error is called Exception.
"""

# Ex:
# ZeroDivisionError: division by zero
# a = 7 / 0


# Ex:
# NameError: name 't' is not defined
# print(t)


# Ex:
a = 12
b = 'B'
# TypeError: unsupported operand type(s) for +: 'int' and 'str'
print(a + b)
