"""
We have covered so far:

try:
    ......
    ......
    ......
except Ex1:
    error
    ......
    ......
except Ex2:
    error
    .......
else:
    .......
    no-errors
finally:
    whether an error or not
    .......
"""

# Ex:
def division(x, y):
    try:
        result = x / y
    except ZeroDivisionError as e:
        print(e)
    else:
        print('Result:', result)
    finally:
        print('Try block is finished...')


# call with zero
# division(12, 0)

# call with valid numbers
# division(12, 4)


# Ex:
# close the file in finally
def open_file(path):
    try:
        file = open(path, encoding='utf-8')
    except Exception as ext:
        print(ext)
    else:
        print(file.read())
    finally:
        try:
            file.close()
            print('Closing the file.')
        except:
            pass

# call with a valid path
# open_file('example.txt')

# call with a wrong path
open_file('exampleeee.txt')








