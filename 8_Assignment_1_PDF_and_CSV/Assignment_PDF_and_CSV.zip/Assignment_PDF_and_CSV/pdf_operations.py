"""
-----------------------------------------------------------
Follow the instructions where you see #TODO statement.
-----------------------------------------------------------
"""

"""
PDF Operations:

* read PDF properties
* read text in PDF
* extract pages from PDF
* combine PDF files
* rotate PDF

"""

"""
Packages we use:
* PyPDF2
    * https://pypi.org/project/PyPDF2/
* pdfplumber:
    * https://pypi.org/project/pdfplumber/
    
These packages are not built-in.
So we have to install them in our virtual environment.
"""

"""
Python packages are in:
"The Python Package Index (PyPI) is a repository of software for the
Python programming language."
* https://pypi.org/

To install a package: pip
https://packaging.python.org/tutorials/installing-packages/
Command Prompt -> cmd
pip install PyPDF2
pip install pdfplumber
"""

"""
The PDF file which we will be using is the official Python Tutorial which was written by,
the creator of Python, Guido van Rossum :)
"""

# pdf_operations.py file

#TODO install PyPDF2 and pdfplumber packages
import os
import PyPDF2
import pdfplumber

# path for pdf
project_path = os.getcwd()
pdf_path = os.path.join(project_path, 'pdf', 'tutorial.pdf')


#--- read PDF properties ---#
def read_pdf_properties():
    # read pdf
    pdf = PyPDF2.PdfFileReader(pdf_path)
    print(pdf_path)
    print(pdf)

    # number of pages
    num_of_pages = #TODO call getNumPages() on pdf
    #TODO print num_of_pages with f-strings

    # get document info
    doc_info = #TODO get documentInfo of pdf

    #TODO print each key-value pair doc_info items




#--- read text in PDF ---#
# single page
def pdf_read_page(page_num=0):
    # pdfplumber -> open()
    with pdfplumber.open(pdf_path) as pdf:
        page = #TODO get page from pdf.pages at page_num index
        content = #TODO extract page text (extract_text())
        print(content)


# multiple pages
def pdf_read_pages(start=0, end=1):
    # pdfplumber -> open()
    with #TODO open pdf_path with pdfplumber:
        for #TODO loop over range from start to end (inc):
            print(f'---------- start of page {i} ----------')

            page = #TODO get page i from pdf
            content = #TODO extract page text (extract_text())
            print(content)

            print(f'---------- end of page {i} ----------')



#--- extract pages from PDF ---#

# Single Page Extraction
def extract_page(page_num=0):

    # import at once
    #TODO import PdfFileReader, PdfFileWriter from PyPDF2 package

    new_pdf_path = os.path.join(project_path, 'pdf', str(page_num) + '.pdf')

    # get the PDF
    pdf = #TODO get PdfFileReader with pdf_path

    # get the page
    page = #TODO get page at page_num of pdf

    # create new pdf
    pdf_writer = #TODO instantiate PdfFileWriter object
    #TODO add page to pdf_writer

    # now, fill the new pdf with the pdf_writer
    # wb -> write binary
    with #TODO open new_pdf_path in write-binary mode:
        pdf_writer.write(result)


# Multiple Pages Extraction
def extract_pages(start=0, end=1):

    # import at once
    #TODO import PdfFileReader, PdfFileWriter from PyPDF2 package

    # ex: 2_8.pdf
    new_pdf_path = os.path.join(project_path, 'pdf', str(start) + '_' + str(end) + '.pdf')

    # get the PDF
    pdf = #TODO get PdfFileReader with pdf_path

    # create new pdf
    pdf_writer = #TODO instantiate PdfFileWriter object

    # add pages
    for #TODO loop over range from start to end (inc):
        # get page
        page = #TODO get page i from pdf

        # add the page into pdf_writer
        #TODO add this page to pdf_writer

    # now, fill the new pdf with the pdf_writer
    # wb -> write binary
    with #TODO open new_pdf_path in write-binary mode:
        #TODO write the pdf_writer into new_pdf_path object



#--- merge PDF files ---#

def pdf_merge(*args):

    # get the class
    # TODO import PdfFileMerger from PyPDF2 package

    # merger object
    merger = #TODO instantiate PdfFileMerger object

    # *args
    #TODO loop over args and append into merger

    # save merger as pdf
    merged_pdf_path = os.path.join(project_path, 'pdf', 'merged_pdf.pdf')

    with #TODO open merged_pdf_path in write-binary mode:
        merger.write(merged_pdf)


#--- rotate PDF files   ---#

def pdf_rotate(degree):
    """
    Rotates the PDF file.
    .rotateClockwise() and
    .rotateCounterClockwise()
    :param degree: int, must be multiples of 90
    :return: None
    """

    #TODO import PdfFileReader, PdfFileWriter from PyPDF2 package

    # read the merged_pdf
    merged_pdf = #TODO read 'pdf/merged_pdf.pdf' with PdfFileReader

    # create a writer
    writer = #TODO instantiate PdfFileWriter object

    # loop over the pages
    for #TODO loop over number of pages in merged_pdf:

        # get the page
        page = #TODO get page i in merged_pdf

        # rotate the page
        #TODO rotate page Clockwise in the given degree

        # pass this page to writer
        #TODO add this page to writer

    with #TODO open 'pdf/rotated.pdf' in write-binary mode:
        writer.write(rotated)




