"""
MRO (Method Resolution Order)
"""

"""
Multiple Level Inheritance:
GrandParent -> Parent -> Child
"""

# _5_mro.py file

class GrandParent(object):
    # GrandParent properties
    pass

class Parent(GrandParent):
    # GrandParent properties
    # Parent properties
    pass

class Child(Parent):
    # GrandParent properties
    # Parent properties
    # Child properties
    pass


# Example
# object > SandWatch > Clock
# object > Calendar
# Clock & Calendar > CalendarClock

# SandWatch Class
class SandWatch(object):
    def __init__(self):
        self.start_sand_watch()

    def start_sand_watch(self):
        print('Sand Watch started.')


# Clock Class
class Clock(SandWatch):
    """Simulates the clock."""

    def __init__(self, hours, minutes, seconds):
        super().__init__()
        self.set_clock(hours, minutes, seconds)

    def set_clock(self, hours, minutes, seconds):
        self.__hours = hours
        self.__minutes = minutes
        self.__seconds = seconds

    def time(self):
        return '{0}:{1}:{2}'.format(self.__hours, self.__minutes, self.__seconds)

    # override start_sand_watch
    def start_sand_watch(self):
        print('Sand Watch started in Clock Class.')


# Calendar Class
class Calendar(object):
    """Simulates the calendar"""

    def __init__(self, d, m, y):
        self.set_calendar(d, m, y)

    def set_calendar(self, d, m, y):
        self.__d = d
        self.__m = m
        self.__y = y

    def date(self):
        return '{d}:{m}:{y}'.format(d=self.__d, m=self.__m, y=self.__y)


# CalendarClock Class
class CalendarClock(Clock, Calendar):
    """Keeps calendar and clock together."""

    def __init__(self, day, month, year, hours, minutes, seconds):
        # call the super classes init methods
        Clock.__init__(self, hours, minutes, seconds)
        Calendar.__init__(self, day, month, year)


# create a CalendarClock
# calender_clock = CalendarClock(12, 1, 2020, 13, 25, 48)

# call the start_sand_watch method
# calender_clock.start_sand_watch()



"""
Question: If we have the same method in different classes which one will be executed?
Answer: It will execute the nearest one.
Method Resolution Order -> MRO
"""

# MRO for CalendarClock
# __mro__
# print('MRO for CalendarClock:')
# for m in CalendarClock.__mro__:
#     print(m)

# MRO for CalendarClock
# mro()
print('MRO for CalendarClock:')
for m in CalendarClock.mro():
    print(m)