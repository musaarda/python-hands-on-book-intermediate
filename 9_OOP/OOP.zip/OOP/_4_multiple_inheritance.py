"""
Multiple Inheritance:
A class can inherit from multiple classes.
"""

# _4_multiple_inheritance.py file

# parent class 1
class Main_1:
    pass

# parent class 2
class Main_2:
    pass

# child inherits from two parents
class SubClass(Main_1, Main_2):
    pass


# Ex
# Clock and Calendar -> CalendarClock will inherit from both

# Clock Class
class Clock:
    """Simulates the clock."""

    def __init__(self, hours, minutes, seconds):
        self.__hours = hours
        self.__minutes = minutes
        self.__seconds = seconds

    def set_clock(self, hours, minutes, seconds):
        self.__hours = hours
        self.__minutes = minutes
        self.__seconds = seconds

    def time(self):
        return '{0}:{1}:{2}'.format(self.__hours, self.__minutes, self.__seconds)


# create a Clock object
# clock = Clock(0, 0, 0)
# print(clock.time())
# clock.set_clock(10, 4, 28)
# print(clock.time())


# Calendar Class
class Calendar(object):
    """Simulates the calendar"""

    def __init__(self, d, m, y):
        self.set_calendar(d, m, y)

    def set_calendar(self, d, m, y):
        self.__d = d
        self.__m = m
        self.__y = y

    def date(self):
        return '{d}:{m}:{y}'.format(d=self.__d, m=self.__m, y=self.__y)


# create a Calendar object
# calendar = Calendar(6, 11, 2019)
# print(calendar.date())
# calendar.set_calendar(16, 1, 2020)
# print(calendar.date())


# CalendarClock Class
class CalendarClock(Clock, Calendar):
    """Keeps calendar and clock together."""

    def __init__(self, day, month, year, hours, minutes, seconds):
        # call the super classes init methods
        Clock.__init__(self, hours, minutes, seconds)
        Calendar.__init__(self, day, month, year)


# create a CalendarClock object
calendar_clock = CalendarClock(8, 12, 2020, 16, 45, 7)
print(calendar_clock)
print(calendar_clock.time())
print(calendar_clock.date())


