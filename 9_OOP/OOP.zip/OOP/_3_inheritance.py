"""
Super Class
    - Child Class 1
    - Child Class 2
"""

# _3_inheritance.py file

class SuperClass:
    # super class properties
    pass

class ChildClass1(SuperClass):
    # super class properties
    # child class 1 properties
    pass

class ChildClass2(SuperClass):
    # super class properties
    # child class 2 properties
    pass


# Ex
import math

# super class -> Shape
class Shape(object):
    """Super class for shapes."""
    def __init__(self, color='red'):
        self.color = color


# sub class -> Circle
class Circle(Shape):
    """Circle inherits from Shape."""
    def __init__(self, radius, color='blue'):
        super().__init__(color=color)
        self.radius = radius

    def area(self):
        return math.pi * self.radius**2


# sub class -> Rectangle
class Rectangle(Shape):
    """Rectangle inherits from Shape."""
    def __init__(self, width=1.0, length=1.0, color='orange'):
        super().__init__(color)
        self.width = width
        self.length = length

    def area(self):
        return self.width * self.length


# sub class -> Square
class Square(Shape):
    """Square inherits from Shape."""
    def __init__(self, side=1.0, color='white'):
        super().__init__(color)
        self.side = side

    def area(self):
        return self.side**2


# Create Objects
# Shape
sh = Shape('purple')
# print('Color of Shape sh:', sh.color)

# Circle
ci = Circle(radius=5)
# print('Radius of Circle ci:', ci.radius)

# color of Circle
# super().__init__(color=color) -> blue
# print('Color of Circle ci:', ci.color)

# Rectangle
re = Rectangle(width=2, length=8, color='yellow')
# print('Color of Rectangle re:', re.color)
# print(re.area())

"""
The 'object' class:
'object' class is the super class of all classes.
root class.
Al the other classes, inherit from 'object'

class SuperClass:  => class SuperClass(object):
"""

# is sh an instance of the object class
# print('Is Shape a subclass of object class?: ', isinstance(sh, object))

# issubclass()
# is Square class is subclass of Shape class
print('Is Square class is subclass of Shape class?: ', issubclass(Square, Shape))



