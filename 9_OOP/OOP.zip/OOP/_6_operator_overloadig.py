"""
Operator Overloading
"""

# _6_operator_overloadig.py file

class Point:
    """A point in coordinate axis."""
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y


# Create two Point Objects
p1 = Point(2, 5)
p2 = Point(-1, 4)

# print('----- before overloading -----')
# print(p1)
# __str__() is String representation of object
# print(p1.__str__())

# print() -> __str__()
# It comes from 'object' class by default
# <_6_operator_overloadig.Point object at 0x0000024858E3A250>

"""
Define our own string representation -> override __str__()  => operator overloading
"""

# override __str__() method
class Point:
    """A point in coordinate axis."""
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y

    # overload __str__()
    def __str__(self):
        return 'This is a point at coordinates: ({0},{1})'.format(self.x, self.y)


# print('----- after overloading -----')
p1 = Point(2, 5)
print(p1)
print(Point.__str__(p1))
