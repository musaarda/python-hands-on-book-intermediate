# _2_classes_and_objects.py file

# Defining a class with docstring
class Car:
    """
    This is the car class.
    """
    # class attribute
    brand = 'BMW'

    def work(self):
        print('This car works.')


# to call the brand attribute -> class
# print(Car.brand)

"""
dunder (double underscore)
methods or attributes with two underscore prefix -> __<attribute_name>
There are built-in dunder methods.
"""

# docstring of class
# print(Car.__doc__)

# class name
# print(Car.__name__)

# get details of work method
# print(Car.work)

# call the work method on the class
# Car.work()

# TypeError: work() missing 1 required positional argument: 'self'
# self -> object

# define an object and call work() on it
new_car = Car()
# print(new_car.brand)
# new_car.work()


"""
Question:
Where is the 'self' parameter?
new_car.work()

Answer:
'self' parameter is new_car itself.
"""

# First parameter is 'self' -> new_car
# Car.work(self=new_car)
# Car.work(new_car)


# Ex
import math

class Circle:

    def __init__(self, radius):
        self.__radius = radius

    def get_radius(self):
        return self.__radius

    def set_radius(self, new_radius):
        if new_radius > 0:
            self.__radius = new_radius
        else:
            print('Radius must be positive.')

    def perimeter(self):
        return math.pi * self.__radius**2


# create an object
circle_1 = Circle(10)
# print(circle_1.get_radius())
# perimeter = circle_1.perimeter()
# print(perimeter)

# print('----- set ------')
# circle_1.set_radius(20)
# perimeter = circle_1.perimeter()
# print(perimeter)


# define a new class
class Student:
    def __init__(self, name, age, grade):
        self.name = name
        self.age = age
        self.grade = grade

# instantiate std object
std = Student('John Doe', 8, '7th Grade')
# print(std.name)
# print(std.age)
# print(std.grade)

# Delete attributes of objects -> del
del std.age

# try to access after delete
# print(std.age)
# AttributeError: 'Student' object has no attribute 'age'


"""
Delete Attribute:
del object.attribute

Delete Object:
del object
"""

# delete std object
del std

# try to access after delete
print(std.age)
# NameError: name 'std' is not defined









