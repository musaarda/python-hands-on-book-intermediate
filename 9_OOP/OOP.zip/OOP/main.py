# main.py file

if __name__ == '__main__':
    # import _1_oop_basics
    # import _2_classes_and_objects
    # import _3_inheritance
    # import _4_multiple_inheritance
    # import _5_mro
    # import _6_operator_overloadig
