# ------------------------------ OOP BASICS ---------------------------#

"""
Object Oriented Programming (OOP)

In Python Objects have:
* attributes
* behaviors

Example:
Penguin
* attributes: name, age, height, weight, color, family...
* behaviors: swim, walk, sing, dance...

OOP: Prevents code repetition
DRY: Do not repeat yourself
"""

"""
Class:
A Class is a blueprint for creating objects.
It is the template for creating objects.
It tells how the objects are going to look like.

Ex: A House is an object. The architectural drawing of that house is the Class.

"""

# _1_oop_basics.py file

# class definition
class Penguin:
    pass



"""
We use 'class' keyword to create a class.
The name of our class is Penguin.
"""

"""
Object:
An Object is an instance of the Class.
Instantiate: Creating Objects from Classes.
We create Object by CALLING Classes.
"""

# create a Penguin object -> peng
peng = Penguin()


"""
Class Attribute:
The attributes that all the Penguins have.
Their scientific family for example -> Spheniscidae
https://en.wikipedia.org/wiki/Penguin
So all the Penguins are from Spheniscidae family.


Instance Attribute:
It is the attributes which are special to each individual Penguin: age, color, height, weight...
"""

"""
Method:
Methods are Functions defined in a Class.
Methods are behaviors of the object.
"""


class Penguin:
    # class attribute
    family = 'Spheniscidae'

    # instance attributes
    def __init__(self, name, age, color):
        self.name = name
        self.age = age
        self.color = color


"""
self: the current object that being created.
"""

# create two Penguin objects
king = Penguin('King Penguin', 4, 'Orange')
yellow_eyed = Penguin('Yellow-Eyed Penguin', 1, 'Brown')

# print the class attributes
# print('Scientific Family of {0} is {1}'.format(king.name, king.__class__.family))
# print('Scientific Family of {0} is {1}'.format(yellow_eyed.name, yellow_eyed.__class__.family))

# class attributes without __class__
# print('Scientific Family of {0} is {1}'.format(king.name, king.family))
# print('Scientific Family of {0} is {1}'.format(yellow_eyed.name, yellow_eyed.family))

# print all instance attributes
# print('Age of {0} is {1}, and its color is {2}'.format(king.name, king.age, king.color))
# print('Age of {0} is {1}, and its color is {2}'.format(yellow_eyed.name, yellow_eyed.age, yellow_eyed.color))



"""
To get Attributes -> '.'
* Class Attributes -> .__class__.
* Instance Attribute -> .
"""

"""
__init__(self, ....):
When we create an object from a class the first method that get called is __init__() method.
It is called as the 'constructor' method.
__init__() creates the instance.

* self: refers the current object that being created.
Attributes:
self.name = ...
self.color = ...
self.age = ...
"""


# Add methods to our Penguin Class
class Penguin:
    # class attributes
    family = 'Spheniscidae'

    # instance attributes
    # constructor
    def __init__(self, name, age, color):
        self.name = name
        self.age = age
        self.color = color

    # methods -> behaviors
    # first parameter -> self
    def swim(self):
        return f'{self.name} can swim.'

    def sing(self, can_sing=False):
        if can_sing:
            return f'{self.name} can sing.'
        else:
            return f'{self.name} can NOT sing.'

    def dance(self, can_dance=False):
        if can_dance:
            return f'{self.name} can dance.'
        else:
            return f'{self.name} can NOT dance.'


#---- Object 1 ->  Rockhopper  ----#
# create new Penguin objects
# rockhopper = Penguin('Rockhopper Penguin', 8, 'Yellow-Brown')

# let's see if rockhopper can swim
# rockhopper.swim() -> Penguin.swim(rockhopper)
# print(rockhopper.swim())

# # is rockhopper can sing
# print(rockhopper.sing(True))

# # is rockhopper can dance
# print(rockhopper.dance(can_dance=False))


#---- Object 2 ->  Happy Feet  ----#
# happy_feet = Penguin('Happy Feet', 1, 'Gray')

# print(happy_feet.swim())

# print(happy_feet.sing(can_sing=False))

# print(happy_feet.dance(can_dance=True))



# ------------------------------ INHERITANCE ---------------------------#

"""

Inheritance:
Classes can inherit from other classes. (like in real world)

Parent Class -> class that is inherited by Child class
Child Class -> class that inherits from Parent class

Parent Class -> Super Class (Base Class)
Child Class -> Derived Class

"""


# Define Bird Class
class Bird:
    def __init__(self):
        print('Bird is created.')

    def whoAmI(self):
        print('I am a Bird.')

    def fly(self):
        print('Birds can fly.')

    def swim(self):
        print('Birds can swim.')


# create a Bird instance
# birdy = Bird()
# birdy.whoAmI()
# birdy.fly()
# birdy.swim()

# We have a Parent Class for all bird types
# Owl is a bird, so it is a child class


# child class
class Owl(Bird):

    # We write parent class/classes inside parenthesis

    def __init__(self):
        # first -> we call __init__() of Super class (super() == Bird)
        super().__init__()
        print('Owl is created.')

    # override the parent methods
    def whoAmI(self):
        print('I am an Owl.')

    # Since all the birds can fly -> Owl also can fly
    # leave fly method as it is -> do not override

    def swim(self):
        print('Owls can not swim.')

    # Owls have night vision
    def night_vision(self):
        print('Owls have night vision.')


# create an Owl
# owl = Owl()
# owl.whoAmI()
# owl.fly()
# owl.swim()
# owl.night_vision()


# birdy is a Bird but not an Owl
# birdy.night_vision()



# ------------------------------ ENCAPSULATION ---------------------------#

"""
Encapsulation (Information Hiding):
We may not want anyone to access the attributes in our class.
We may want to control the access.
Encapsulation provides information hiding.

Attribute hiding: is done via '__' 
Attributes with '__' prefix (__<attr_name>) becomes Private.

Private means, it can only accessible inside the class.
"""

# Let's assume we have a Telephone class
class Telephone:
    def __init__(self):
        # let's define the standard price of the telephone -> private attribute
        self.__price = 1000

    def sell(self):
        print('Selling price is: ${}'.format(self.__price))

    # setter
    def set_price(self, new_price):
        # check if the price is negative
        if new_price <= 0:
            print('Price must be POSITIVE.')
        else:
            self.__price = new_price

    # getter
    def get_price(self):
        return self.__price


# create a Telephone object
phone = Telephone()

# we want to access its price
# phone.__price
# AttributeError: 'Telephone' object has no attribute '__price'
# __price is Private


# sell the phone
# phone.sell()  # $1000

# set the price -> $5000
phone.__price = 5000

# sell the phone
# phone.sell()  # $1000

# print the value of phone.__price
# print(phone.__price)
# again we see as $1000 -> because we didn't set the __price in the class
# phone.__price -> Python creates a new attribute


# You can set attributes to the objects,
# independent of their classes.
# phone.color = 'Black'
# print(phone.color)

# How do we set the price.


"""
Get-Set Methods -> Getter-Setter
We use them to set and get the Private Attributes of a class.
"""

# set the price to 8000
phone.set_price(8000)

# get the current price
# price = phone.get_price()
# print('Current Price is:', price)

# sell the phone again
# phone.sell()  # $8000


"""
Why do we need Encapsulation?
To give all the control to the class.
It can check in set methods.
"""

# Ex:
# If you want to set a negative price
# Price -> -2000
# phone.set_price(-2000)
# price = phone.get_price()
# print('Current Price is:', price)


# ------------------------------ POLYMORPHISM ---------------------------#

"""
Polymorphism:
(many forms)
It refers to the same object (or function) exhibiting different forms and behaviors.
"""

# child class
class Owl(Bird):
    # We write parent class/classes inside parenthesis

    def __init__(self):
        # first -> we call __init__() of Super class (super() == Bird)
        # super().__init__()
        print('Owl is created.')

    # override the parent methods
    def whoAmI(self):
        print('I am an Owl.')

    def fly(self):
        print('Some owls can not fly.')

    def swim(self):
        print('Owls can not swim.')

    # Owls have night vision
    def night_vision(self):
        print('Owls have night vision.')


# penguin class
class Penguin(Bird):
    # We write parent class/classes inside parenthesis

    def __init__(self):
        # super().__init__()
        print('Penguin is created.')

    # override the parent methods
    def whoAmI(self):
        print('I am a Penguin.')

    # override fly
    def fly(self):
        print('Penguins can not fly.')

    # leave the swim method as it is


# two child classes from the same parent class
# Owl, Penguin <---- Bird

# common function
def can_it_fly(bird):
    # call the fly method on the parameter bird
    bird.fly()


# create three objects -> Bird, Owl, Penguin
bird = Bird()
owl = Owl()
penguin = Penguin()

# call with three objects -> Bird, Owl, Penguin
print("#--- Fly Test ---#")
can_it_fly(bird)
can_it_fly(owl)
can_it_fly(penguin)


"""
The same function can_it_fly returns different results based on the object as its parameter.
"""











