"""
 [10 Questions] QUIZ - File Operations
"""

# --------------------------------------------------------------------------------------#

# Q 1:
"""
Open the 'quiz_files/flower_names.txt' file in this project with Python.
And print the flower names.

Hints:
* os
* read mode ('r')
"""

# Q 1:
path = 'quiz_files/flower_names.txt'

# --- your solution here ---


# --------------------------------------------------------------------------------------#

# Q 2:
"""
Open the 'quiz_files/flower_names.txt' file in this project with Python.
And append the name below to this file:

'Z: Zinnia elegans'

Finally print all the file content.

Hints:
* os
* append mode ('a')
"""

# Q 2:

path = 'quiz_files/flower_names.txt'
new_flower = 'Z: Zinnia elegans'

# --- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 3:
"""
Create a file named 'quiz_files/file_to_delete.txt'.
And add the content below into this file:
'This file will be deleted in the Quiz.'

Hints:
* os
* to create file -> mode='x'
* encoding
"""

# Q 3:

import os

path = 'quiz_files/file_to_delete.txt'

# --- your solution here ---


# --------------------------------------------------------------------------------------#

# Q 4:
"""
Delete the file 'quiz_files/file_to_delete.txt' you created in Q3.
Add exception handling to handle the case of not finding such a file.

Hints:
* os
* try-except
* to delete -> os.remove()
"""

# Q 4:

# --- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 5:
"""
Get the list of all content (files and folders) in this project directory.
Use this methods:
1- os.listdir()
2- os.scandir()
3- pathlib.Path.iterdir()

"""

# Q 5:

import os
from pathlib import Path

# 1st Way:
# os.listdir()
# --- your solution here ---

# 2nd Way
# os.scandir()
# --- your solution here ---

# 3rd Way
# Path
# . -> current folder location
# --- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 6:
"""
Create the folder tree below in the 'quiz_files' directory:

- quiz_files
    - folder 1
        - sub folder 1
        - sub folder 2
    - folder 2
    - folder 3
        - sub folder 3

Create all of them one by one with os.mkdir().

"""

# Q 6:

# --- your solution here ---


# --------------------------------------------------------------------------------------#

# Q 7:
"""
Create the folder tree below in the 'quiz_files' directory.
This time create with the methods described in parenthesis.

- quiz_files

    (os.makedirs)
    - folder 10
        - sub folder 10
        - sub folder 20
    
    (pathlib.Path.mkdir)
    - folder 20
    
    (pathlib.Path.mkdir)
    - folder 30
        - sub folder 30
        
Handle 'FileExistsError' exception if the file already exists.

Hints:
* os
* os.makedirs()
* pathlib.Path.mkdir()
* exist_ok=True
* parents
"""

# Q 7:

import os
from pathlib import Path

# (os.makedirs)
# --- your solution here ---

# (pathlib.Path.mkdir)
# --- your solution here ---


# --------------------------------------------------------------------------------------#

# Q 8:
"""
Find all the files which has '*a*d*.py' in the file name.
Use Comprehensions for both getting the list and printing it.

Hints:
* os
* os.scandir()
* os.getcwd()
* fnmatch
"""

# Q 8:

import os
import fnmatch

# get the list
# --- your solution here ---

# print the list
# --- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 9:
"""
Delete all the files and folders in the 'quiz_files' directory, which has '1' in its name.

Use os.path.join to join the current project path (os.getcwd) and 'quiz_files'.
And make it as your search path.

Use a single Comprehension to find and delete them.

Hints:
* shutil.rmtree()
* os.getcwd()
* os.path.join()
"""

# Q 9:

import os
import shutil
import fnmatch

# create the search path
# --- your solution here ---

# define the pattern
# --- your solution here ---

# find the files with pattern and print
# --- your solution here ---

# remove files and folders with pattern
# --- your solution here ---

# --------------------------------------------------------------------------------------#

# Q 10:
"""
Create an archive (zip) folder out of 'quiz_files' folder.
The name of the archive folder is going to be 'quiz_folder_archive.zip'.

Hints:
* shutil.make_archive()
"""

# Q 10:

# --- your solution here ---


# --------------------------------------------------------------------------------------#