"""
ARCHIVE FILE Opeations
zipfile
"""

import os

# print the project content
# for d in os.listdir():
#     print(d)

# let's open zip file
import zipfile
# archive = zipfile.ZipFile('neural_style_transfer.zip', 'r')
# print(archive)

# let's see what's in it
# for d in archive.filelist:
#     print(d)

# extract it
# archive.extractall()

# close the file
# archive.close()

# CREATE ZIP FILES
import shutil
# create an archive file
shutil.make_archive('new_archive_folder', 'zip', 'neural_style_transfer')