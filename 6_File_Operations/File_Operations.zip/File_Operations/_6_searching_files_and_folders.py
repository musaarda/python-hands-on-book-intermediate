"""
Two ways to search:

1- String Methods -> startswith, endswith, find

2- fnmatch module (recommended)
"""

import os
from pathlib import Path

# Ex: String Methods

# search path for the current project
search_path = '.'

# for k in os.listdir(search_path):
#     print(k)

# let's get .py files
# with Path(search_path) as path:
#     # get content
#     for content in path.iterdir():
#         # check type is file and ends with .py
#         if content.is_file() and content.name.endswith('.py'):
#             print(content.name)


# fnmatch module (recommended)
import fnmatch

# match pattern with * char
pattern = '*.py'

with Path(search_path) as folder:
    for f in folder.iterdir():
        if f.is_file() and fnmatch.fnmatch(f.name, pattern):
            print(f.name)




