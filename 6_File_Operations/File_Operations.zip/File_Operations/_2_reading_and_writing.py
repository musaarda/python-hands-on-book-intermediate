"""
Reading - Writing
"""

"""
Reading Methods:
* read() -> all content_up_to at once
* readline() -> reads single line and waits for the next one
* readlines() -> reads all the remaining lines
"""

# Ex -> Reading

# with open('lorem_ipsum.txt', mode='rt', encoding='utf-8') as lorem:
#     content = lorem.read()
#     print(content)

# read the first 50 chars
# with open('lorem_ipsum.txt', mode='rt', encoding='utf-8') as lorem:
#     content_up_to = lorem.read(50)  # read 50 chars
#     print(content_up_to)

# read the file line by line -> first line
# with open('lorem_ipsum.txt', mode='rt', encoding='utf-8') as lorem:
#     line_1 = lorem.readline()
#     print(line_1)


# read the file line by line -> first two lines
# with open('lorem_ipsum.txt', mode='rt', encoding='utf-8') as lorem:
#     # read the first line
#     line_1 = lorem.readline()
#     print(line_1)
#     # read the second line
#     line_2 = lorem.readline()
#     print(line_2)

# print the file info
# with open('lorem_ipsum.txt', mode='rt', encoding='utf-8') as lorem:
#     print(lorem)

# read all the lines one by one -> for loop
# with open('lorem_ipsum.txt', mode='rt', encoding='utf-8') as lorem:
#     for line in lorem:
#         print(line)

# read all the lines one by one -> for loop
# get the sentences only
# with open('lorem_ipsum.txt', mode='rt', encoding='utf-8') as lorem:
#     for line in lorem:
#         # split(): splits the text from space chars
#         # space chars: ' ', \n, \t
#         line_content = line.split('\n')
#         # split() returns a list
#         sentence = line_content[0]
#         print(sentence)




"""
Writing Modes:
* w: write   -> clear all the content and open as blank file (DANGEROUS)
* a: append  -> appends the new content to the existing one  (SAFE)
"""

# open with w mode
# with open('lorem_ipsum.txt', mode='w') as lorem:
#     lorem.write('New Line from Code')

# open with a mode
# with open('lorem_ipsum.txt', mode='a') as lorem:
#     lorem.write('New Line with append mode...')


# append multiple lines at once
with open('lorem_ipsum.txt', mode='a') as lorem:
    list_to_append = ['\nMulti Line 1', '\nMulti Line 2', '\nMulti Line 3']
    lorem.writelines(list_to_append)



















