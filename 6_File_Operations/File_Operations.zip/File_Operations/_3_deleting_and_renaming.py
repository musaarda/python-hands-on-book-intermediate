"""
We use os module to:
* rename
* delete
* create
files
"""

import os

# RENAME
# os.rename('file_to_rename.txt', 'file_with_new_name.txt')

# FileNotFoundError  -> if the file not exists
# exception handling
# try:
#     os.rename('file_to_rename.txt', 'file_with_new_name.txt')
# except:
#     print('File not found with this name.')


# DELETE -> remove(), unlink()

# remove a file in the current folder
# os.remove('file_with_new_name.txt')

# unlink a file in the current folder
# os.unlink('unlink.txt')


# CREATE -> mode='x'

# create a file and write some content in it
# with open('file_to_create.txt', mode='x') as new_file:
#     new_file.write('This is a new file with mode x....')

# FileExistsError -> if you try to create an existing file
try:
    with open('file_to_create.txt', mode='x') as new_file:
        new_file.write('This is a new file with mode x....')
except:
    print('File already exist....')