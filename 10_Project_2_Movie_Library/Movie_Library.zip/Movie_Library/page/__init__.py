# __init__.py file of page package

"""
package for pages.
Pages: Home, Movie List, Movie Detail
"""

from .home.Home import Home
from .movie_list.MovieList import MovieList
from .movie_detail.MovieDetail import MovieDetail
