# geometry.py file

class GEOMETRY:
    """Class for Geometry constants."""

    MAIN_WINDOW_WIDTH = 960
    MAIN_WINDOW_HEIGHT = 880
