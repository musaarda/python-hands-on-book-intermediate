# __init__.py file of the widget package

"""
modules and packages -> main entry point
"""

# import modules and packages -> . notation
# from .[file_path] import Class
from .window.Window import Window
from .left_frame.LeftFrame import LeftFrame
from .button.Button import Button
from .right_frame.RightFrame import RightFrame
