# button.py file

# import
import tkinter as tk

# main window
window = tk.Tk()
window.title('Tkinter Basics - Button')
window.geometry('600x400')  # width x height

# Button Widget
btn = tk.Button(master=window,
                text='Close',
                # text-unit -> width (width of one char of text)
                width=45,
                # height (height of one char of text)
                height=10,
                bg='red',
                fg='white',
                # what to do when clicked
                command=window.destroy)

# place the button
btn.pack()

# last line -> mainloop
window.mainloop()
