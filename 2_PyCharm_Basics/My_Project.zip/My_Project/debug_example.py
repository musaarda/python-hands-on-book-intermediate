# define a function to add numbers
def summation(x_1, x_2):
    sum_of_nums = x_1 + x_2
    return sum_of_nums

# define two variables
a = 2
b = 5

# call the function
summation(a, b)