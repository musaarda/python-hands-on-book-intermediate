"""
consontants module.
"""

def get_consonants(text):

    consonants = set()

    vowels = 'aeiou'

    try:
        for letter in text:
            if letter.lower() not in vowels and letter.isalpha():
                consonants.add(letter)
    except:
        pass
    finally:
        return consonants