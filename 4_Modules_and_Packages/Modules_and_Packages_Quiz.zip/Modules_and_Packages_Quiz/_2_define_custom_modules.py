"""
module: .py file
"""

# define our first module
import first_module

# call the function in module
# first_module.greeting()

# import module
import input_operations as io

# text_input = io.get_input()
# print(text_input)

# user_integer = io.get_integer()
# print(user_integer)

user_float = io.get_float()
print(user_float)
