"""
This package has two modules:

* mod_1
* mod_2

"""

# absolute import
# wrong way
# import mod_1
# import mod_2

# correct import
# relative import
from . import mod_1
from . import mod_2




