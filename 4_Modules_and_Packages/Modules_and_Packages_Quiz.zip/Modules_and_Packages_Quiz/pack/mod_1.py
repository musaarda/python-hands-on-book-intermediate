
def print_mod_1():
    print('Module 1')