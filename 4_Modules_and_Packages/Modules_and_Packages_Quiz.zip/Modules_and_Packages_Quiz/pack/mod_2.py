
def print_mod_2():
    print('Module 2')