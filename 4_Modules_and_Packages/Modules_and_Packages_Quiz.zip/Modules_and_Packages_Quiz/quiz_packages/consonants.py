"""
consontants module.
"""

# absolute import
# import vowels

# relative import
from . import vowels_list as vowels

def get_consonants(text):

    consonants = set()

    try:
        for letter in text:
            if letter.lower() not in vowels and letter.isalpha():
                consonants.add(letter)
    except:
        pass
    finally:
        return consonants