"""
Quiz Package
"""

# global variables
vowels_list = 'aeiou'

# import
# relative import
# . -> current folder
from . import consonants, vowels
