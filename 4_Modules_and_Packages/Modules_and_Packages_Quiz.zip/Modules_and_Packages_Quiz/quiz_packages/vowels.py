"""
vowels module.
"""

# absolute import
# import vowels

# relative import
from . import vowels_list as vowels

def get_vowels(text):

    vowels_set = set()

    try:
        for letter in text:
            if letter.lower() in vowels and letter.isalpha():
                vowels_set.add(letter)
    except:
        pass
    finally:
        return vowels_set