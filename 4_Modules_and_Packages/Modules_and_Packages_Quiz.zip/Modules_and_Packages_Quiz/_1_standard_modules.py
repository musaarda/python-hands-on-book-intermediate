"""
Standard Modules
"""

"""
Modular Programming:
1- Prevents code repetition
2- Better organization (web, db, api...)
3- Easy Maintenance
"""

"""
Module: A Python file ending with .py 
Package: Python special folders including one or more modules
"""

"""
import
"""

import math

# pi number
pi_num = math.pi

# print(pi_num)

# random package
import random

# 0 - 1
probability = random.random()
# print(probability)

# random number
rand_num = random.randint(10, 50)
# print(rand_num)

# random list
a_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
rand_item = random.choice(a_list)
# print(rand_item)

# random range -> sample
rand_sample = random.sample(a_list, 3)
# print(rand_sample)


"""
platform
"""

import platform
# print(platform)

# platform type
# print('platform type:', platform.platform())

# platform architecture
# print('platform architecture:', platform.architecture())

# machine data
# print('machine:', platform.machine())

# OS data
# print('OS:', platform.system())


"""
os
"""

import os

# print('os module:', os)

# current folder of our project
# print(os.getcwd())

# logged in user
# print(os.getlogin())


"""
sys
"""
import sys

# path variable
paths = sys.path

# print('Python Search Paths for Modules:')
# for path in paths:
#     print(path)

# sys.path -> the list where Python looks for modules


"""
import syntax
* import ..... as ....
* multiple imports 
    * import random, math, sys
* import specific packages
    * from ... import ....
* import specific packages and rename (aliasing)
    * from ... import .... as ....
* import all (not recommended)
    * from ... import *
    
"""

import random as rnd
# print(rnd.random())

# multiple modules
import random, math, sys, os


# sub module
from sys import modules
# print(modules)


# alise the import
from math import sqrt as sq
# print(sqrt(16))
print(sq(16))

# import all from random


# this leads name clash
from random import *

def randint():
    print('ABC')

print(randint(10,20))









