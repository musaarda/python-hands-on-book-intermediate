"""
 QUIZ - Modules and Packages
"""
# --------------------------------------------------------------------------------------#

# Q 1:
"""
Define a function named 'random_printer'.
It will import the random module and will print a random number between 100 and 200.

Hints:
* randint()
"""

# Q 1:

#---- your solution here ----

# call the function you defined
random_printer()

# --------------------------------------------------------------------------------------#

# Q 2:
"""
Define a function named 'random_list'.
It will import random module with custom name 'rnd'.
And it will create a list of size 10.
The items in the list are random values between 100 and 200.
The function will print the list all at once.

Then it will randomly select 4 of the items in this list and print them.

Hints:
* randint()
* sample()
"""

# Q 2:

#---- your solution here ----

# call the function you defined
random_list()

# --------------------------------------------------------------------------------------#

# Q 3:
"""
Print the current project path via the os module.

Hints:
* getcwd()
"""

# Q 3:

#---- your solution here ----


# --------------------------------------------------------------------------------------#

# Q 4:
"""
Print your computers:
* Operating System
* Processor
using standard Python modules.

Hints:
* platform
"""

# Q 4:

#---- your solution here ----


# --------------------------------------------------------------------------------------#

# Q 5:
"""
Print the Python Search Path via the sys module.
Python Search Path is the list of paths which Python uses when looking for modules.
Print the items one by one by the help of a for loop.

Hints:
* path
"""

# S 5:




# --------------------------------------------------------------------------------------#

# Q 6:
"""
Create a module named 'consonants' in the current project.
Define a function named 'get_consonants' in this module.
This function takes a text as parameter and it will return a set of consonants in this text.
Call this function with a text and print the consonants in this text.

Hints:
* your module should implement its own exception handling

Expected Output:
'Pyton Programming Language.... /@*-'

{'r', 'P', 'L', 'y', 'm', 'n', 't', 'g'}
"""

# Q 6:
#-- create the consonants module first --

# import the module you create
import consonants

text = 'Pyton Programming Language A.... /@*-'
cons = consonants.get_consonants(text)
print(cons)


# --------------------------------------------------------------------------------------#

# Q 7:
"""
Create a module named 'vowel' and make it available for all files in this project.
In this module define a function named 'get_vowels'.
This function takes a text as parameter and it will return a set of vowels in this text.
Call this function with a text and print the vowels in this text.

Hints:
* your module should implement it's own exception handling
* inspect sys.path
* venv/lib/site-packages

Expected Output:
'Pyton Programming Language.... /@*-'

{'a', 'e', 'i', 'o', 'u'}
"""

# Q 7:

#-- create the vowel module first --

import vowel

text = 'Pyton Programming Language .... /@*-'
vows = vowel.get_vowels(text)
print(vows)

# --------------------------------------------------------------------------------------#

# Q 8:
"""
Create a Python Package named 'quiz_packages' in the current project folder.
Copy the modules you created in Q6 (consonants) and Q7 (vowel) in this package.
Import these modules from quiz_packages package and use their functions (get_consonants, get_vowels)

Hints:
* Python Package (__init__.py)
* global variables in the __init__.py file.

Expected Output:
text = 'Pyton Programming Language.... /@*-'

get_consonants(text) -> {'n', 'm', 'P', 'L', 'r', 'g', 'y', 't'}
get_vowels(text) -> {'i', 'o', 'u', 'a', 'e'}
"""

# Q 8:

#-- create the quiz_packages first --

import quiz_packages

text = 'Pyton Programming Language.... /@*-'
cons = quiz_packages.consonants.get_consonants(text)
vows = quiz_packages.vowels.get_vowels(text)
print(cons)
print(vows)


# --------------------------------------------------------------------------------------#

# Q 9:
"""
Copy the 'quiz_packages' Python Package you created in Q8.
Now make it available for all Python projects on your machine.
In other words, make it a global package.
And rename it as 'quiz_packages_global'.

Hints:
* create a global Python Package
* sys.path
* to see where Python is installed on your machine:
    * command prompt (cmd) -> where python

Expected Output:
text = 'Pyton Programming Language.... /@*-'

get_consonants(text) -> {'r', 'P', 'y', 'm', 'n', 'L', 't', 'g'}
get_vowels(text) -> {'i', 'a', 'o', 'e', 'u'}
"""

# Q 9:

#-- create the quiz_packages_global first --

import quiz_packages_global
cons = quiz_packages_global.consonants.get_consonants(text)
vows = quiz_packages_global.vowels.get_vowels(text)
print(cons)
print(vows)


# --------------------------------------------------------------------------------------#

# Soru 10:
"""
Which one below is NOT True for Python Modules?

A- In Python, a module is a file with .py extension.
B- We use 'import' keyword to access the modules.
C- In Python, a Package is a container containing modules
D- Python packages are ordinary folders. It is enough to create a folder to define a Python package.
"""

# S 10:




# --------------------------------------------------------------------------------------#
