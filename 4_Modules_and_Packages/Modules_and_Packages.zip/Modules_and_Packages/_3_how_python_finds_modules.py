"""
import <modul_name>

Python looks for modules as follows:
1- Searches the current folder that the code runs (same level)
2- PYTHONPATH environment variable -> if it's defined system level
3- In the folders where Python is installed (virtual environments)

sys.path -> displays Python search paths

"""

# import sys module
import sys

# Search Paths of Python
python_search_path = sys.path

# print the paths
# for path in python_search_path:
#     print(path)

# directory access (dir_name.module_name)
import modules.module_input_operations

# call the get_input function
# user_input = modules.module_input_operations.get_input()
# print(user_input)


"""
It is not a good practice to get modules with folder path.
Folder names or path may change.
"""

"""
Project level access:
Modules_and_Packages\venv\lib\site-packages
"""

import local_module_input_operations

# user_input = local_module_input_operations.get_input()
# print(user_input)


"""
System level access (global access):
...\Python\Python39\lib
"""

import global_input_operations

print(global_input_operations.get_integer())