"""
module: mod_1
"""

def print_mod_1():
    print('Module 1')