"""
__init__.py
The pack package has two modules:
* mod_1
* mod_2
"""

# absolute import
# wrong way
# import mod_1
# import mod_2

# relative import
# correct way
from . import mod_1
from . import mod_2