"""
module: input_operations
This module is for input operations.
"""

def get_input(type='text'):
    return input('Please enter a/an {0}: '.format(type))

def get_integer():
    while True:
        try:
            user_input = get_input(type='integer')
            num = int(user_input)
        except:
            continue
        else:
            return num

def get_float():
    while True:
        try:
            user_input = get_input(type='float')
            flt = float(user_input)
        except:
            continue
        else:
            return flt