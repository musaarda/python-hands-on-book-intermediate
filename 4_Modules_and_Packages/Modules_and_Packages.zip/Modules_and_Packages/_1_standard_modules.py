"""
Standard Modules
"""

"""
Modular Programming:
1- Prevents code repetition
2- Better organization (web, db, api...)
3- Easy Maintenance
"""

"""
Module: A Python file ending with .py 
Package: Python special folders including one or more modules
"""

"""
import
"""

# import the math module
import math

# pi number
pi_num = math.pi
# print(pi_num)


# random module
import random

# 0 - 1
probability = random.random()
# print(probability)

# random number
rand_num = random.randint(10, 50)
# print(rand_num)

# a random element from a list
a_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
rand_item = random.choice(a_list)
# print(rand_item)

# a random range -> sample
rand_sample = random.sample(a_list, 3)
# print(rand_sample)


"""
platform
"""

import platform
# print(platform)

# platform type
# print('platform type:', platform.platform())

# platform architecture
# print('platform architecture:', platform.architecture())

# machine data
# print('machine:', platform.machine())

# OS data
# print('OS:', platform.system())


"""
os
"""

import os

# current folder of our project
# print(os.getcwd())

# logged in user
# print(os.getlogin())


"""
sys
"""
import sys

# path variable
paths = sys.path

# print('Python Search Paths for Modules:')
# for path in paths:
#     print(path)

# sys.path -> the list where Python looks for modules


"""
import syntax
* import ..... as ....
* multiple imports 
    * import random, math, sys
* import specific packages
    * from ... import ....
* import specific packages and rename (aliasing)
    * from ... import .... as ....
* import all (not recommended)
    * from ... import *
    
"""

# give a custom name
import random as rnd
# print(rnd.random())

# import multiple modules
import random, math, sys, os

# import single function
from random import randint
a_random_number = randint(1, 11)
# print(a_random_number)


# import a dictionary
from sys import modules
# print(modules)


# custom name for the imported object
from math import sqrt as sq
# print(sq(16))

# import all from random


# this leads name clash
from random import *

# define a function named randint
def randint(a, b):
    print('ABC')

# call the randint function
print(randint(10,20))









