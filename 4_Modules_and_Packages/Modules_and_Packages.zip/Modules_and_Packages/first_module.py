"""
this module prints:
'Hello Python Module' statement.
"""

def greeting():
    print('Hello Python Module')