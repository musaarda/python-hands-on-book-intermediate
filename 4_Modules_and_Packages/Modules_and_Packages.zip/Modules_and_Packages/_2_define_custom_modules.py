"""
module: .py file
"""

# import our first module
import first_module

# call the function in module
# first_module.greeting()

# import module
import input_operations as io

# call the get_input function
# text_input = io.get_input()
# print(text_input)

# call the get_integer function
# user_integer = io.get_integer()
# print(user_integer)

# call the get_float function
user_float = io.get_float()
print(user_float)
