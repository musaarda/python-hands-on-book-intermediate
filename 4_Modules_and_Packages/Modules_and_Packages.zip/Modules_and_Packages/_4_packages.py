"""
Packages:
* organize the code
* portable
* arrange modules
"""

"""
Python Packages -> are actually folders
* difference -> they include "__init__.py" file.
"""

"""
Access a module under a Package:
* pack1.mod1
* pack2.mod2.mod21..
"""

# import the modules in the pack package
import pack.mod_1, pack.mod_2
# pack.mod_1.print_mod_1()
# pack.mod_2.print_mod_2()


"""
__init__.py:

* in the  __init__.py  file:
    * sub packages and imports for modules
    * global variables
    * documentation
"""

# import the package
import pack

# access the modules
pack.mod_1.print_mod_1()
pack.mod_2.print_mod_2()


