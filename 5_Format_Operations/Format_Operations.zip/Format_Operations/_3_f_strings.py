"""
3. f-strings (String Interpolation)

* f".... string ... {}"

"""

# _3_f_strings.py file

# define two variables
x = 2
y = 3

# calculate the multiplication
multiplication = x * y

# print in f-string
# print(f"{x} * {y} = {multiplication}")

# more Pythonic way
# in {} we write Python statements
# print(f"{x} * {y} = {x * y}")

# list in f-string
info = ['Clark Kent', 'Metropolis', 'Daily Planet']
print(f'{ info[0] } lives in { info[1] } and works for { info[2] }')

# Note:
# f-strings were introduced with Python 3.6
# f-strings are faster than % operator and str.format()