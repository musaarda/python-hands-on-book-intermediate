"""
% operator

placeholders:
- %s -> string
- %d -> integer
- %f -> float
    - %.<n>f -> n decimal places

"""
# _1_format_operator.py file

# %s
# define a variable
day = 'Monday'
# use % operator
my_string = 'Today is %s' % day
# print(my_string)


# %d
# define a numeric variable
num = 28
# use % operator in the print fn
# print('%d is a perfect number.' % num)


# %f
import math
pi = math.pi
text = 'pi number in math: %f' % pi
# print(text)


# %.nf
import math
pi = math.pi
text = 'pi number in math: %.2f' % pi
# print(text)

# Multiple placeholders with % operator
info = 'Python released in %d and being used %.1f years' % (1991, 30)
# print(info)

# Tuple with % operator
info = ('Peter', 'Parker', 28)
question = "%s %s is %d years old." % info
# print(question)

# Dictionary with % operator
file = {
    'path': './com/pty.py',
    'version': 1.8,
    'author': 'Musa Arda'
}
file_info = " P: %(path)s \n V: %(version).1f \n A: %(author)s" % file
print(file_info)





