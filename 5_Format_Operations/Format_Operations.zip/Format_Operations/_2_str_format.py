"""
2- String Format

str.format()
formatting with {}
"""

# _2_str_format.py file

# without indexing
hi = 'Hi there {} {}'
# print(hi.format('Peter', 'Parker'))

# with indexing
statement = 'The word {0} has {1} letters.'
# print(statement.format('Python', len('Python')))

# parameter names
text = '{n} comes from {s}'
language = text.format(n='Python', s="Monty Python's Flying Circus")
# print(language)

# named placeholders
text = '{lang} comes from {source}'
language = text.format(lang='Java', source='Java Coffee type, in Java Island')
print(language)


