"""
4- Template Strings

* Template Class under 'string' module
* $ is the place holder

"""

# _4_template_strings.py file

from string import Template

# Ex 1
name = 'Bruce Wayne'
hero = 'Batman'

temp = Template('$h is $n')
# print(temp.substitute(h=hero, n=name))

# Ex 2
num_1 = 5
num_2 = 8
result = num_1 + num_2

temp = Template('$a + $b = $c')
print(temp.substitute(a=num_1, b=num_2, c=result))

