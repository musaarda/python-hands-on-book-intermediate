"""
 QUIZ - Format Operations
"""

#--------------------------------------------------------------------------------------#

# Q 1:
"""
Define a function named 'day_names'.
It will ask for a day name from the user.
And will return a Tuple including the day name and number of letters in it.
Ex: (Sunday, 6)

Call this function and get the result Tuple, and then print the string below:
'Sunday has 6 letters.'

Hints:
* use % operator
"""

# Q 1:

# define the function
# --- your solution here ---

# call the function you defined
# --- your solution here ---

# print with % operator
# --- your solution here ---


#--------------------------------------------------------------------------------------#

# Q 2:
"""
Call the function in Q1 and print the result with str.format() as follows:
'day: Monday, length: 6'

Hints:
•	use str.format()
"""

# Q 2:

# call the day_names function
# --- your solution here ---

# print with str.format()
# --- your solution here ---


#--------------------------------------------------------------------------------------#

# Q 3:
"""
Call the function in Q1 and print the result with f-strings as follows:
'day: Monday, length: 6'

Hints:
•	use f-string
"""

# Q 3:

# call the day_names function
# --- your solution here ---

# print with f-string
# --- your solution here ---

#--------------------------------------------------------------------------------------#

# Q 4:
"""
Call the function in Q1 and print the result with Template Strings as follows:
'day: Monday, length: 6'

Hints:
•	use Template Strings
"""

# Q 4:

# import the necessary class
# --- your solution here ---

# call the day_names function
# --- your solution here ---

# instantiate a template object with placeholders
# --- your solution here ---

# print with Template String
# --- your solution here ---


#--------------------------------------------------------------------------------------#

# Use the dictionary below for Questions 5, 6, 7, 8, 9, 10:
capitals = {
    'USA': 'Washington',
    'China': 'Beijing',
    'Germany': 'Berlin',
    'UK': 'London'
}

#--------------------------------------------------------------------------------------#

# Q 5:
"""
Use the capitals dictionary and % operator to print as follows:
"The capital city of USA is Washington"
'USA' will be constant, 'Washington' will be a variable.
"""

# Q 5:

# --- your solution here ---


#--------------------------------------------------------------------------------------#

# Q 6:
"""
Use the capitals dictionary and str.format() to print as follows:
"The capital city of Germany is Berlin"
Both 'Germany' and 'Berlin' will be variables.
"""

# Q 6:

# --- your solution here ---


#--------------------------------------------------------------------------------------#

# Q 7:
"""
Use the capitals dictionary and f-strings to print as follows:
"The capital city of UK is London"
Both 'UK' and 'London' will be variables.
"""

# Q 7:

# --- your solution here ---


#--------------------------------------------------------------------------------------#

# Q 8:
"""
Use the capitals dictionary and Template Strings to print as follows:
"The capital city of USA is Washington"
Both 'USA' and 'Washington' will be variables.
"""

# Q 8:

# --- your solution here ---


#--------------------------------------------------------------------------------------#

# Q 9:
"""
Print the country names and capitals by using a for loop and f-strings as follows:
'<capital> is the capital of <country>'

Expected Output:
Washington is the capital of USA
Beijing is the capital of China
Berlin is the capital of Germany
London is the capital of UK
"""

# Q 9:

# --- your solution here ---


# --------------------------------------------------------------------------------------#

# Q 10:
"""
Print the country names and capitals by using Comprehension and f-strings as follows:
'<capital> is the capital of <country>'

Expected Output:
Washington is the capital of USA
Beijing is the capital of China
Berlin is the capital of Germany
London is the capital of UK
"""

# Q 10:

# --- your solution here ---


# --------------------------------------------------------------------------------------#

