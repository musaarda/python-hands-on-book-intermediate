# widget/left_frame/LeftFrame.py file

import tkinter as tk
from data.colors import COLORS
from data.menus import MENU

# exact import
from widget.button.Button import Button
from widget.right_frame.RightFrame import RightFrame

class LeftFrame:
    """
    Class for Left Frame to hold the menu items.
    """

    # TODO - define the init method for the LeftFrame

    def add_frame(self):
        self.frame.pack(side=tk.LEFT, fill=tk.Y, pady=(62, 0))

    # method for click event of menu buttons -> event handler
    def handle_click(self, event):
        self.manage_button_colors(event)
        page_name = str(event.widget).split('.')[2]
        # print('Page {0} is clicked.'.format(page_name))

        # self is left frame -> master = root
        # right frame is in children of master
        rightFrame = self.master.children['rightFrame']

        # destroy children
        # TODO - call destroy_children() method of RightFrame

        # add new page -> page_name
        # TODO - call frame_content() method of RightFrame

    def add_menus(self):
        # add menus in loop
        for menu_key, menu_text in MENU.items():
            if menu_key == 'about':
                button = # TODO - create the Button Widget
            else:
                # TODO - create the Button Widget

                if menu_key == 'home':
                    self.selected_button_color(button.button)

    def manage_button_colors(self, event):
        # clicked button -> event.widget
        # all the menu buttons -> event.widget.master.children
        for child in event.widget.master.winfo_children():
            if child == event.widget:
                child.configure(bg=COLORS.ORANGE, fg=COLORS.WHITE)
            else:
                # TODO - configure the child as background = BLACK and foreground = ORANGE

    def selected_button_color(self, button):
        # tk button configure
        # TODO - configure the button as background = ORANGE and foreground = WHITE
