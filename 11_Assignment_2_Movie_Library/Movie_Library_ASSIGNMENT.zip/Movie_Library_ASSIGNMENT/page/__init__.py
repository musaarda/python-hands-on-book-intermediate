"""
package for pages.
Pages:
    1- Home
    2- Movie List
    3- Movie Detail
"""

from .home.Home import Home
# TODO - import MovieList
# TODO - import MovieDetail

