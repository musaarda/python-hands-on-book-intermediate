# main.py file

"""
This is the main file of Movie Library:
Pages:
    1- Home
    2- Movie List
    3- Movie Detail

https://www.imdb.com/chart/top/
"""

from widget import Window, LeftFrame, RightFrame

if __name__ == '__main__':

    # Root Window
    # TODO - Create the root object by calling Window class

    # LEFT FRAME
    # TODO - Create the left frame by calling LeftFrame class

    # RIGHT FRAME
    # TODO - Create the right frame by calling RightFrame class

    # start root window -> mainloop()
    # TODO - start the main window (root)

