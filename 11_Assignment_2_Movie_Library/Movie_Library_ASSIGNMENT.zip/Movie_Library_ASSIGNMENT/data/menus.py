MENU = {
    'home': 'Home',
    'movieList': 'Movie List',
    'movieDetail': 'Movie Detail',
    'about': 'About',
}
