"""
PDF Operations:

* read PDF properties
* read text in PDF
* extract pages from PDF
* merge PDF files
* rotate PDF

"""

"""
Packages we use:
* PyPDF2
    * https://pypi.org/project/PyPDF2/
* pdfplumber:
    * https://pypi.org/project/pdfplumber/
    
These packages are not built-in.
So we have to install them in our virtual environment.
"""

"""
Python packages are in:
"The Python Package Index (PyPI) is a repository of software for the
Python programming language."
* https://pypi.org/

To install a package: pip
https://packaging.python.org/tutorials/installing-packages/
Command Prompt -> cmd
pip install PyPDF2
pip install pdfplumber
"""

"""
The PDF file which we will be using is the official Python Tutorial which was written by,
the creator of Python, Guido van Rossum :)
"""

# pdf_operations.py file

import os
import PyPDF2
import pdfplumber

# path for pdf
project_path = os.getcwd()
pdf_path = os.path.join(project_path, 'pdf', 'tutorial.pdf')


#--- read PDF properties ---#
def read_pdf_properties():
    # read pdf
    pdf = PyPDF2.PdfFileReader(pdf_path)
    print(pdf_path)
    print(pdf)

    # number of pages
    num_of_pages = pdf.getNumPages()
    print(f'Number of pages: {num_of_pages}')

    # get document info
    doc_info = pdf.documentInfo

    for key, value in doc_info.items():
        print(f'{key}: {value}')



#--- read text in PDF ---#
# single page
def pdf_read_page(page_num=0):
    # pdfplumber -> open()
    with pdfplumber.open(pdf_path) as pdf:
        page = pdf.pages[page_num]
        content = page.extract_text(x_tolerance=1)
        print(content)


# multiple pages
def pdf_read_pages(start=0, end=1):
    # pdfplumber -> open()
    with pdfplumber.open(pdf_path) as pdf:
        for i in range(start, end + 1):
            print(f'---------- start of page {i} ----------')

            page = pdf.pages[i]
            content = page.extract_text(x_tolerance=1)
            print(content)

            print(f'---------- end of page {i} ----------')



#--- extract pages from PDF ---#

# Single Page Extraction
def extract_page(page_num=0):
    # import classes at once
    from PyPDF2 import PdfFileReader, PdfFileWriter

    # define a path for extracted pdf
    new_pdf_path = os.path.join(project_path, 'pdf', str(page_num) + '.pdf')

    # get the PDF
    pdf = PdfFileReader(pdf_path)

    # get the page
    page = pdf.getPage(page_num)

    # create new pdf
    pdf_writer = PdfFileWriter()
    pdf_writer.addPage(page)

    # now, fill the new pdf with the pdf_writer
    # wb -> write binary
    with open(new_pdf_path, 'wb') as result:
        pdf_writer.write(result)


# Multiple Pages Extraction
def extract_pages(start=0, end=1):
    # import at once
    from PyPDF2 import PdfFileReader, PdfFileWriter

    # ex: 2_8.pdf
    new_pdf_path = os.path.join(project_path, 'pdf', str(start) + '_' + str(end) + '.pdf')

    # get the PDF
    pdf = PdfFileReader(pdf_path)

    # create new pdf
    pdf_writer = PdfFileWriter()

    # add pages
    for i in range(start, end+1):
        # get page
        page = pdf.getPage(i)

        # add the page into pdf_writer
        pdf_writer.addPage(page)

    # now, fill the new pdf with the pdf_writer
    # wb -> write binary
    with open(new_pdf_path, 'wb') as result:
        pdf_writer.write(result)



#--- merge PDF files ---#

def pdf_merge(*args):
    # get the class
    from PyPDF2 import PdfFileMerger

    # merger object
    merger = PdfFileMerger()

    # *args
    for arg in args:
        merger.append(arg)

    # save merger as pdf
    merged_pdf_path = os.path.join(project_path, 'pdf', 'merged_pdf.pdf')

    # now, fill the new pdf with the merger
    with open(merged_pdf_path, 'wb') as merged_pdf:
        merger.write(merged_pdf)


#--- rotate PDF files   ---#

def pdf_rotate(degree):
    """
    Rotates the PDF file.
    .rotateClockwise() and
    .rotateCounterClockwise()
    :param degree: int, must be multiples of 90
    :return: None
    """
    #

    from PyPDF2 import PdfFileReader, PdfFileWriter

    # read the merged_pdf
    merged_pdf = PdfFileReader('pdf/merged_pdf.pdf')

    # create a writer
    writer = PdfFileWriter()

    # loop over the pages
    for i in range(merged_pdf.getNumPages()):
        # get the page
        page = merged_pdf.getPage(i)

        # rotate the page
        page.rotateClockwise(degree)

        # pass this page to writer
        writer.addPage(page)

    # now, fill the new pdf with the writer
    with open('pdf/rotated.pdf', 'wb') as rotated:
        writer.write(rotated)




