"""
CSV: Comma Separated Values
Either it has ',' or ';' as the separator.
"""

# In Python -> csv module
# https://docs.python.org/3/library/csv.html

import csv

# define the file paths
movie_path = 'data/movies.csv'
movie_path_semicolon = 'data/movies_semicolon.csv'

#------------  READIND CSV  --------------#

# delimiter = ,
def csv_read():
    with open(movie_path, 'r') as file:
        # first get a csv reader
        movies = csv.reader(file, delimiter=',')

        # csv.reader() returns -> iterator
        for movie in movies:
            # each line is a list
            print(movie)


# delimiter = ;
def csv_read_semicolon():
    with open(movie_path_semicolon, 'r') as file:
        # first get a csv reader
        movies = csv.reader(file, delimiter=';')

        # csv.reader() returns -> iterator
        for movie in movies:
            # each line is a list
            print(movie)


"""
Dialect is a format for reading CSV files.
"""

# read with dialect
def csv_read_dialect():

    csv.register_dialect('normal_read',
                         delimiter=',',
                         quoting=csv.QUOTE_MINIMAL)

    with open(movie_path, 'r') as file:
        # first get a csv reader
        movies = csv.reader(file, dialect='normal_read')

        for movie in movies:
            print(movie)


# before running the reader() it recommended to check if reader can operate on this file
# is it a valid CSV file or not

# sniffer fn to get data about csv file
def csv_sniffer():
    with open(movie_path_semicolon, 'r') as file:
        # get file content
        content = file.read()
        # check if the file has a valid header
        has_reader = csv.Sniffer().has_header(content)
        print('CSV Has Valid Reader:', has_reader)

        # check if the file has a delimiter
        dialect = csv.Sniffer().sniff(content)
        print('Delimiter:', dialect.delimiter)


#------------  WRITING TO CSV  --------------#

# IMPORTANT NOTE: We will open the files in 'a' mode, NOT IN 'w'

# define the new row to add
movie_to_add = ["250","Slumdog Millionaire","2008","R","25 Dec 2008",
                "120 min","Drama", "Danny Boyle, Loveleen Tandan",
                "Simon Beaufoy (screenplay), Vikas Swarup (novel)",
                "Dev Patel, Saurabh Shukla, Anil Kapoor, Raj Zutshi",
                "A Mumbai teen reflects on his upbringing in the ...",
                "English, Hindi, French","UK, France, USA",
                "Won 8 Oscars. Another 144 wins & 126 nominations.",
                "https://images-na.ssl-images-amazon.com/...jpg",
                "Internet Movie Database","8.0/10","86","8.0","679,975",
                "tt1010048","movie","N/A","N/A","N/A","N/A","N/A",
                "N/A","N/A","N/A","N/A","N/A",
                "http://www.rottentomatoes.com/m/slumdog_millionaire/",
                "31 Mar 2009","$141,243,551",
                "Fox Searchlight Pictures",
                "http://www.../slumdogmillionaire/","True"]

def csv_write():
    with open(movie_path, 'a', newline='') as file:

        # get a csv writer
        writer = csv.writer(file, delimiter=',', quoting=csv.QUOTE_ALL)

        # write the row as movie
        writer.writerow(movie_to_add)


# two CSV files simultaneously
def csv_copy():
    # new path
    new_movie_path = 'data/movies_copy.csv'

    # create the new file -> 'x'
    open(new_movie_path, 'x')

    # open both files at the same time
    with open(movie_path, 'r') as movies, \
         open(new_movie_path, 'a', newline='') as movies_copy:
        # reader from the first one
        movies_to_copy = csv.reader(movies)

        # writer for the second one
        writer = csv.writer(movies_copy, quoting=csv.QUOTE_ALL)

        # loop over movies to copy one by one -> write into the new file
        for movie in movies_to_copy:
            writer.writerow(movie)
