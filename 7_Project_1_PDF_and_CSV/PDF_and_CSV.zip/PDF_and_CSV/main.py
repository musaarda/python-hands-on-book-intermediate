# main.py file

import csv_operations
import pdf_operations

if __name__ == '__main__':
    # csv_operations.csv_read()
    # csv_operations.csv_read_semicolon()
    # csv_operations.csv_read_dialect()
    # csv_operations.csv_sniffer()
    # csv_operations.csv_write()
    # csv_operations.csv_copy()
    # pdf_operations.read_pdf_properties()
    # pdf_operations.pdf_read_page(2)
    # pdf_operations.pdf_read_pages(62, 68)
    # pdf_operations.extract_page(8)
    # pdf_operations.extract_pages(2,8)
    # pdf_operations.pdf_merge('pdf/8.pdf', 'pdf/2_8.pdf')
    # pdf_operations.pdf_rotate(90)